//
//  TapConnectSDK.h
//  TapConnectSDK
//
//  Created by 黄驿峰 on 2023/8/11.
//

#import <Foundation/Foundation.h>

//! Project version number for TapConnectSDK.
FOUNDATION_EXPORT double TapConnectSDKVersionNumber;

//! Project version string for TapConnectSDK.
FOUNDATION_EXPORT const unsigned char TapConnectSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TapConnectSDK/PublicHeader.h>

#import <TapConnectSDK/TapConnect.h>

